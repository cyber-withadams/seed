import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  Heart,
  Target,
  Award,
  Shield,
  Clock,
  GraduationCap,
  Stethoscope,
  TreePine,
  Building,
  Send,
  ArrowRight,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import livelihoodTraining from "@/assets/Livelihood and Skills Training.jpg";

const JoinPage = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    interest: "",
    availability: "",
    skills: "",
    motivation: "",
    newsletter: false,
  });

  const [showServiceUnavailable, setShowServiceUnavailable] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value, type } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);

    setShowServiceUnavailable(true);
    setTimeout(() => setShowServiceUnavailable(false), 3000);

    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      interest: "",
      availability: "",
      skills: "",
      motivation: "",
      newsletter: false,
    });
  };

  const opportunities = [
    {
      icon: <Shield className="h-8 w-8 text-gray-600" />,
      title: "Protection Case Worker",
      description:
        "Support refugee protection services, case management, and rights advocacy in Nakivale Refugee Settlement.",
      timeCommitment: "15-20 hours/week",
      skills: [
        "Case Management",
        "Human Rights",
        "Documentation",
        "Cultural Sensitivity",
      ],
      urgent: true,
    },
    {
      icon: <Heart className="h-8 w-8 text-blue-600" />,
      title: "Disability Inclusion Assistant",
      description:
        "Assist with disability inclusion programs, accessibility support, and specialized services for persons with disabilities.",
      timeCommitment: "10-15 hours/week",
      skills: [
        "Sign Language",
        "Disability Support",
        "Patience",
        "Communication",
      ],
      urgent: true,
    },
    {
      icon: <GraduationCap className="h-8 w-8 text-gray-600" />,
      title: "Education Program Volunteer",
      description:
        "Support educational programs, literacy classes, and skills training for refugee children and youth.",
      timeCommitment: "8-12 hours/week",
      skills: [
        "Teaching",
        "Mentoring",
        "Curriculum Development",
        "Language Support",
      ],
      urgent: false,
    },
    {
      icon: <Stethoscope className="h-8 w-8 text-red-600" />,
      title: "Health Outreach Assistant",
      description:
        "Assist with health screening, mental health support, and psychosocial services for refugee communities.",
      timeCommitment: "12-16 hours/week",
      skills: ["Health Support", "First Aid", "Counseling", "Community Health"],
      urgent: true,
    },
    {
      icon: <TreePine className="h-8 w-8 text-emerald-600" />,
      title: "Livelihood & Agriculture Support",
      description:
        "Support climate-smart agriculture initiatives, livelihood training, and food security programs.",
      timeCommitment: "10-15 hours/week",
      skills: [
        "Agriculture",
        "Training",
        "Business Development",
        "Sustainability",
      ],
      urgent: false,
    },
    {
      icon: <Building className="h-8 w-8 text-purple-600" />,
      title: "Operations & Logistics Support",
      description:
        "Assist with camp operations, logistics coordination, and administrative support for humanitarian programs.",
      timeCommitment: "15-20 hours/week",
      skills: [
        "Logistics",
        "Administration",
        "Coordination",
        "Problem Solving",
      ],
      urgent: false,
    },
  ];

  const benefits = [
    {
      title: "Make a Real Impact",
      description:
        "See the direct results of your contributions in our community.",
      icon: <Target className="h-6 w-6 text-gray-600" />,
    },
    {
      title: "Develop New Skills",
      description:
        "Gain valuable experience and develop new abilities through hands-on work.",
      icon: <Award className="h-6 w-6 text-blue-600" />,
    },
    {
      title: "Build Your Network",
      description:
        "Connect with like-minded individuals and community leaders.",
      icon: <Users className="h-6 w-6 text-purple-600" />,
    },
    {
      title: "Flexible Scheduling",
      description:
        "Find opportunities that fit your availability and lifestyle.",
      icon: <Clock className="h-6 w-6 text-orange-600" />,
    },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Education Volunteer",
      message:
        "Volunteering with SeedMove has been incredibly rewarding. I've seen firsthand how our programs are changing lives in our community.",
      duration: "2 years",
    },
    {
      name: "Michael Chen",
      role: "Event Coordinator",
      message:
        "The skills I've gained and the people I've met through SeedMove have been invaluable. It's more than volunteering—it's being part of a movement.",
      duration: "1 year",
    },
    {
      name: "Emily Rodriguez",
      role: "Outreach Volunteer",
      message:
        "SeedMove gave me the opportunity to give back while developing my professional skills. It's a win-win that I'm proud to be part of.",
      duration: "6 months",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Side - Text Content */}
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                <span className="text-gray-700 flex flex-row">Join Us</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Join our refugee-led humanitarian team in Nakivale Refugee
                Settlement. Whether you're a professional seeking meaningful
                work or a community member wanting to make a difference, there's
                a place for you in our mission to support persons with
                disabilities and their families.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gray-800 hover:bg-gray-900"
                >
                  <Link to="#volunteer-form">
                    Apply Now <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/about">
                    Learn More <Users className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Right Side - Image */}
            <div className="order-first md:order-last">
              <img
                src={livelihoodTraining}
                alt="Join Our Team - Livelihood and Skills Training opportunities"
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Why Volunteer With Us?
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">{benefit.icon}</div>
                <h3 className="font-semibold mb-2">{benefit.title}</h3>
                <p className="text-gray-600 text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Opportunities Section */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Volunteer Opportunities
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {opportunities.map((opportunity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    {opportunity.icon}
                    {opportunity.urgent && (
                      <Badge variant="destructive">Urgent Need</Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl">{opportunity.title}</CardTitle>
                </CardHeader>

                <CardContent>
                  <p className="text-gray-600 mb-4">
                    {opportunity.description}
                  </p>

                  <div className="mb-4">
                    <div className="text-sm font-semibold text-gray-700 mb-2">
                      Time Commitment:
                    </div>
                    <div className="text-sm text-gray-600">
                      {opportunity.timeCommitment}
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="text-sm font-semibold text-gray-700 mb-2">
                      Skills Needed:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {opportunity.skills.map((skill, idx) => (
                        <Badge
                          key={idx}
                          variant="secondary"
                          className="text-xs"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full bg-gray-600 hover:bg-gray-700"
                    onClick={() => {
                      const element = document.getElementById("volunteer-form");
                      element?.scrollIntoView({ behavior: "smooth" });
                      setFormData((prev) => ({
                        ...prev,
                        interest: opportunity.title,
                      }));
                    }}
                  >
                    Apply for This Role
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Volunteer Form */}
      <section id="volunteer-form" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Start Your Journey</CardTitle>
              <p className="text-gray-600">
                Fill out the form below and we'll contact you about next steps
              </p>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={handleInputChange}
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={handleInputChange}
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>

                <div>
                  <Label>Area of Interest *</Label>
                  <Select
                    value={formData.interest}
                    onValueChange={(value) =>
                      handleSelectChange("interest", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your area of interest" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="program">Program Volunteer</SelectItem>
                      <SelectItem value="outreach">
                        Community Outreach
                      </SelectItem>
                      <SelectItem value="events">Event Support</SelectItem>
                      <SelectItem value="professional">
                        Professional Services
                      </SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Availability</Label>
                  <Select
                    value={formData.availability}
                    onValueChange={(value) =>
                      handleSelectChange("availability", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your availability" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekdays">Weekdays</SelectItem>
                      <SelectItem value="weekends">Weekends</SelectItem>
                      <SelectItem value="evenings">Evenings</SelectItem>
                      <SelectItem value="flexible">Flexible</SelectItem>
                      <SelectItem value="as-needed">As Needed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="skills">Relevant Skills & Experience</Label>
                  <Textarea
                    id="skills"
                    name="skills"
                    rows={3}
                    value={formData.skills}
                    onChange={handleInputChange}
                    placeholder="Tell us about any skills or experience that might be relevant..."
                  />
                </div>

                <div>
                  <Label htmlFor="motivation">
                    Why do you want to volunteer with SeedMove? *
                  </Label>
                  <Textarea
                    id="motivation"
                    name="motivation"
                    rows={4}
                    required
                    value={formData.motivation}
                    onChange={handleInputChange}
                    placeholder="Share what motivates you to join our mission..."
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="newsletter"
                    name="newsletter"
                    checked={formData.newsletter}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({
                        ...prev,
                        newsletter: checked as boolean,
                      }))
                    }
                  />
                  <Label htmlFor="newsletter" className="text-sm">
                    I'd like to receive updates about SeedMove's work and
                    volunteer opportunities
                  </Label>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-gray-600 hover:bg-gray-700"
                >
                  <Send className="mr-2 h-4 w-4" />
                  Submit Application
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Hear From Our Volunteers
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <p className="text-gray-600 mb-4 italic">
                    "{testimonial.message}"
                  </p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">
                      {testimonial.role}
                    </div>
                    <div className="text-xs text-gray-600">
                      Volunteer for {testimonial.duration}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Information Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Visit Our Location
          </h2>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Card */}
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <MapPin className="h-6 w-6 mr-2 text-gray-600" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Address</h4>
                  <p className="text-gray-600">
                    Nyarugugu C Village
                    <br />
                    Nakivale Refugee Settlement
                    <br />
                    Isingiro District, SouthWest Uganda
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Contacts</h4>
                  <div className="space-y-2">
                    <div className="flex items-center text-gray-600">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>+256 775 506 917</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>+256 708 666 968</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Mail className="h-4 w-4 mr-2" />
                      <span>bisimwaalvin@gmail.com</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Branches</h4>
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <Building className="h-4 w-4 mr-2 mt-1 text-gray-600" />
                      <div>
                        <div className="font-medium">Main Branch</div>
                        <div className="text-gray-600">Nakivale Base Camp</div>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Building className="h-4 w-4 mr-2 mt-1 text-gray-600" />
                      <div>
                        <div className="font-medium">Extension Branch</div>
                        <div className="text-gray-600">Rubondo Sub-zone</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Map Card */}
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="text-xl">Find Us</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden relative">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=-0.7784,30.9478,-0.7784,30.9478&layer=mapnik&marker=-0.7783813341243302,30.947943527766284"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="rounded-lg"
                  />
                  <div className="absolute bottom-4 left-4 bg-white px-3 py-2 rounded-lg shadow-lg">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-gray-600" />
                      <span className="text-sm font-medium text-gray-700">
                        Nyarugugu C Village, Nakivale Refugee Settlement,
                        Isingiro District, SouthWest Uganda
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />

      {/* Service Unavailable Popup */}
      {showServiceUnavailable && (
        <div className="fixed top-4 right-4 bg-gray-800 text-white px-6 py-4 rounded-lg shadow-lg z-50">
          <div className="flex items-center">
            <span>Service not yet implemented</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default JoinPage;
