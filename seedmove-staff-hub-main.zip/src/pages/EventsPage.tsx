import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Calendar,
  Clock,
  Users,
  MapPin,
  Search,
  Heart,
  Shield,
  HandHeart,
  GraduationCap,
  Stethoscope,
  TreePine,
  X,
  ArrowRight,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import sportsActivities from "@/assets/Sports and Leisure Activities.jpeg";

const EventsPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [showServiceUnavailable, setShowServiceUnavailable] = useState(false);

  const events = [
    {
      id: 1,
      title: "Refugee Protection Workshop",
      date: "2026-04-15",
      time: "9:00 AM - 12:00 PM",
      location: "Nakivale Refugee Settlement - Community Center",
      category: "protection",
      description:
        "Essential training on refugee rights, protection protocols, and case management for field officers and community leaders.",
      attendees: 45,
      maxAttendees: 60,
      icon: Shield,
    },
    {
      id: 2,
      title: "Disability Inclusion Training",
      date: "2026-04-20",
      time: "2:00 PM - 5:00 PM",
      location: "SeedMove Training Facility",
      category: "disability",
      description:
        "Comprehensive training on inclusive practices, accessibility standards, and supporting persons with disabilities in humanitarian settings.",
      attendees: 28,
      maxAttendees: 40,
      icon: Heart,
    },
    {
      id: 3,
      title: "Community Health Outreach",
      date: "2026-04-25",
      time: "10:00 AM - 3:00 PM",
      location: "Zone 3 Health Post - Nakivale",
      category: "health",
      description:
        "Free medical screenings, mental health support, and psychosocial services for refugee families and host community members.",
      attendees: 120,
      maxAttendees: 200,
      icon: Stethoscope,
    },
    {
      id: 4,
      title: "Donor Partnership Meeting",
      date: "2026-05-10",
      time: "6:00 PM - 10:00 PM",
      location: "UNHCR Coordination Office",
      category: "partnership",
      description:
        "Strategic partnership development meeting with donor agencies and NGOs to align on program objectives and funding mechanisms.",
      attendees: 85,
      maxAttendees: 150,
      icon: HandHeart,
    },
    {
      id: 5,
      title: "Climate-Smart Agriculture Training",
      date: "2026-05-18",
      time: "8:00 AM - 12:00 PM",
      location: "Agricultural Demonstration Site",
      category: "livelihood",
      description:
        "Training on sustainable farming practices, food security initiatives, and climate-resilient agricultural techniques for refugee farmers.",
      attendees: 32,
      maxAttendees: 100,
      icon: TreePine,
    },
    {
      id: 6,
      title: "Education & Skills Development Workshop",
      date: "2026-05-22",
      time: "1:00 PM - 4:00 PM",
      location: "SeedMove Learning Center",
      category: "education",
      description:
        "Vocational skills training, literacy programs, and educational support for refugee youth and adults seeking economic empowerment.",
      attendees: 18,
      maxAttendees: 30,
      icon: GraduationCap,
    },
  ];

  const categories = [
    { value: "all", label: "All Events" },
    { value: "protection", label: "Protection" },
    { value: "disability", label: "Disability Inclusion" },
    { value: "health", label: "Health" },
    { value: "partnership", label: "Partnership" },
    { value: "livelihood", label: "Livelihood" },
    { value: "education", label: "Education" },
  ];

  const filteredEvents = events.filter((event) => {
    const matchesSearch =
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      selectedCategory === "all" || event.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      protection: "bg-gray-100 text-gray-800",
      disability: "bg-blue-100 text-blue-800",
      health: "bg-red-100 text-red-800",
      partnership: "bg-purple-100 text-purple-800",
      livelihood: "bg-gray-100 text-gray-800",
      education: "bg-yellow-100 text-yellow-800",
    };

    return colors[category] || "bg-gray-100 text-gray-800";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const handleRegisterClick = (event: any) => {
    setSelectedEvent(event);
    setShowModal(true);
  };

  const handleSubmitRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    setShowModal(false);
    setShowServiceUnavailable(true);
    setTimeout(() => setShowServiceUnavailable(false), 3000);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Side - Text Content */}
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                <span className="text-gray-700 flex flex-row">
                  Upcoming Events
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Join our community events and be part of the positive change
                happening in our area. From volunteer opportunities to
                educational workshops, there&apos;s something for everyone.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gray-800 hover:bg-gray-900"
                >
                  <Link to="/join">
                    Get Involved <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/support">
                    Support Events <Users className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Right Side - Image */}
            <div className="order-first md:order-last">
              <img
                src={sportsActivities}
                alt="Community Events - Sports and Leisure Activities"
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search events..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
              />
            </div>

            <div className="flex gap-2 flex-wrap">
              {categories.map((category) => (
                <Button
                  key={category.value}
                  variant={
                    selectedCategory === category.value ? "default" : "outline"
                  }
                  size="sm"
                  onClick={() => setSelectedCategory(category.value)}
                  className={
                    selectedCategory === category.value
                      ? "bg-gray-600 hover:bg-gray-700"
                      : ""
                  }
                >
                  {category.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-gray-600">
                No events found matching your criteria.
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredEvents.map((event) => (
                <Card
                  key={event.id}
                  className="hover:shadow-lg transition-shadow"
                >
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-lg">
                        <event.icon className="h-6 w-6 text-gray-600" />
                      </div>
                      <Badge className={getCategoryColor(event.category)}>
                        {categories.find((c) => c.value === event.category)
                          ?.label || event.category}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl">{event.title}</CardTitle>
                  </CardHeader>

                  <CardContent>
                    <p className="text-gray-600 mb-6">{event.description}</p>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-2 text-gray-600" />
                        {formatDate(event.date)}
                      </div>

                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-2 text-gray-600" />
                        {event.time}
                      </div>

                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2 text-gray-600" />
                        {event.location}
                      </div>

                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="h-4 w-4 mr-2 text-gray-600" />
                        {event.attendees}/{event.maxAttendees} attending
                      </div>
                    </div>

                    <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                      <div
                        className="bg-gray-600 h-2 rounded-full"
                        style={{
                          width: `${
                            (event.attendees / event.maxAttendees) * 100
                          }%`,
                        }}
                      />
                    </div>

                    <Button
                      className="w-full bg-gray-600 hover:bg-gray-700"
                      onClick={() => handleRegisterClick(event)}
                    >
                      Register for Event
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Past Events Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Recent Success Stories
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  Spring Planting Festival
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Over 200 volunteers came together to plant 1,000 trees across
                  5 community parks.
                </p>
                <div className="text-sm text-gray-600 font-semibold">
                  March 2026 • 200+ volunteers
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Youth Career Fair</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Connected 150 high school students with local businesses and
                  career opportunities.
                </p>
                <div className="text-sm text-gray-600 font-semibold">
                  February 2026 • 25 companies
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  Community Health Screening
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Provided free health screenings to 300 community members,
                  identifying critical health needs.
                </p>
                <div className="text-sm text-gray-600 font-semibold">
                  January 2026 • 300+ screenings
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />

      {/* Registration Modal */}
      {showModal && selectedEvent && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900">
                Register for Event
              </h2>

              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
                type="button"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="mb-4">
              <h3 className="font-semibold text-gray-900">
                {selectedEvent.title}
              </h3>
              <p className="text-sm text-gray-600">
                {formatDate(selectedEvent.date)} • {selectedEvent.time}
              </p>
              <p className="text-sm text-gray-600">{selectedEvent.location}</p>
            </div>

            <form onSubmit={handleSubmitRegistration} className="space-y-4">
              <div>
                <Label
                  htmlFor="name"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Full Name *
                </Label>
                <Input
                  id="name"
                  type="text"
                  required
                  className="w-full"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <Label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  required
                  className="w-full"
                  placeholder="Enter your email address"
                />
              </div>

              <div>
                <Label
                  htmlFor="phone"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Phone Number *
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  required
                  className="w-full"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <Label
                  htmlFor="organization"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Organization (Optional)
                </Label>
                <Input
                  id="organization"
                  type="text"
                  className="w-full"
                  placeholder="Your organization or institution"
                />
              </div>

              <div>
                <Label
                  htmlFor="message"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Additional Information (Optional)
                </Label>
                <Textarea
                  id="message"
                  className="w-full"
                  rows={3}
                  placeholder="Any special requirements or questions"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowModal(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>

                <Button
                  type="submit"
                  className="flex-1 bg-gray-600 hover:bg-gray-700"
                >
                  Submit Registration
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Service Unavailable Popup */}
      {showServiceUnavailable && (
        <div className="fixed top-4 right-4 bg-gray-800 text-white px-6 py-4 rounded-lg shadow-lg z-50">
          <div className="flex items-center">
            <span>Service not available yet</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventsPage;
